#!/usr/bin/env python3
"""ClauseKit local server.

Serves the pages in this folder and adds one API:
  GET  /api/health  -> is an AI key configured?
  POST /api/review  -> reviews a contract with the AI model against the playbook below.

Uses only the Python standard library. Run:  python3 server.py
Put your API key in a file named .env in this folder:
  AI_API_KEY=your-key-here
  AI_MODEL=model-id-from-your-provider
"""
import base64
import html
import io
import json
import os
import re
import ssl
import sys
import urllib.error
import urllib.request
import zipfile
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
PORT = int(os.environ.get("PORT", "8765"))
MAX_UPLOAD = 15 * 1024 * 1024  # 15 MB


def load_env():
    path = os.path.join(HERE, ".env")
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


load_env()
MODEL = os.environ.get("AI_MODEL", "").strip()


# ---------------------------------------------------------------------------
# PLAYBOOK: the lawyer's standard positions. This is the product's "brain".
# Your lawyer partner should rewrite these. Each has an id the AI cites back.
# ---------------------------------------------------------------------------
PLAYBOOK = [
    ("CONF-TERM", "Confidentiality", "Confidentiality should survive 2 to 5 years after termination. Perpetual confidentiality is acceptable only for trade secrets."),
    ("LIAB-CAP", "Limitation of liability", "Liability should be mutual and capped at 1x the fees paid or payable in the previous 12 months. Indirect and consequential losses excluded. Carve-outs only for fraud, breach of confidentiality and IP infringement."),
    ("INDEM", "Indemnity", "Indemnities should be mutual and limited to third-party claims caused by the indemnifying party's breach, negligence or IP infringement. Flag one-sided or uncapped indemnities."),
    ("PAY", "Payment terms", "Payment within 30 days of a valid GST invoice. More than 45 days is a problem if the supplier is an MSME (MSMED Act, 2006, Section 15). TDS deduction should be acknowledged."),
    ("LD", "Penalties / liquidated damages", "Under Section 74 of the Indian Contract Act, 1872, only reasonable compensation is recoverable. Flag fixed penalties that look punitive."),
    ("NONCOMP", "Non-compete", "Post-termination non-compete restraints are generally void under Section 27 of the Indian Contract Act, 1872. Non-solicitation during the term is usually acceptable."),
    ("IP", "Intellectual property", "If the client is to own the work, the assignment must be in writing and state the rights, territory and duration (Copyright Act, 1957, Section 19). If duration or territory is missing, it defaults to 5 years and India only. Provider keeps pre-existing IP."),
    ("TERM", "Termination", "Both parties should be able to terminate for material breach (with a cure period of at least 15 days) and for convenience on at least 30 days' notice. Flag one-sided termination rights."),
    ("RENEW", "Auto-renewal", "Flag automatic renewal unless there is a clear opt-out window of at least 30 days."),
    ("AMEND", "Amendments", "Amendments must be in writing and signed by both parties. Flag any right for one party to change terms unilaterally."),
    ("LAW", "Governing law and disputes", "Governing law should be Indian law. Prefer arbitration under the Arbitration and Conciliation Act, 1996 with a named seat in India, or exclusive jurisdiction of a named Indian city. Flag foreign law or foreign seat for Indian parties."),
    ("DATA", "Personal data", "If personal data is shared or processed, require compliance with the Digital Personal Data Protection Act, 2023: purpose limitation, reasonable security safeguards, breach notification, and erasure on termination."),
    ("STAMP", "Execution and stamp duty", "Agreement must be properly stamped under the applicable State stamp law before or at execution, and signed by authorised signatories."),
    ("ASSIGN", "Assignment", "Neither party should assign the contract without the other's written consent, except to an affiliate or acquirer with notice."),
]

SYSTEM_PROMPT = """You are a contract review assistant for an Indian law firm. You help a qualified lawyer review contracts faster. You do not give final legal advice; the lawyer decides.

Review the contract against the firm's PLAYBOOK of standard positions. For every clause that departs from the playbook, or that is risky for the user's side, report an issue. Also report playbook topics that are missing from the contract when they matter for this kind of contract.

Rules:
- Quote the contract's exact words in "quote" (keep each quote under 40 words). Never invent text that is not in the contract.
- Be specific and practical. Cite Indian statutes only when you are confident they apply.
- Severity: "high" = could cause serious loss or is likely unenforceable; "medium" = one-sided or unusual, should be negotiated; "low" = drafting or clarity issue.
- If the document is not a contract, say so in the summary and return no issues.

Respond with ONLY a JSON object, no other text, in this exact shape:
{
  "contract_type": "short name, e.g. Master Services Agreement",
  "parties": ["Party 1", "Party 2"],
  "summary": "2-3 plain-English sentences on what this contract does and the overall risk",
  "overall_risk": "high" | "medium" | "low",
  "issues": [
    {"severity": "high"|"medium"|"low", "playbook_id": "ID from playbook or OTHER", "title": "short title",
     "quote": "exact words from the contract", "problem": "why this is a problem, plain English",
     "suggestion": "what to change, ideally replacement wording"}
  ],
  "missing": [
    {"playbook_id": "ID", "title": "what is missing", "why": "why it matters here"}
  ]
}
Order issues from high to low severity."""


def playbook_text(side):
    lines = [f"[{pid}] {title}: {rule}" for pid, title, rule in PLAYBOOK]
    who = {
        "client": "The user is the CLIENT (the party receiving services / paying).",
        "provider": "The user is the SERVICE PROVIDER (the party doing the work / being paid).",
    }.get(side, "The user's side is not specified: point out risks for both parties.")
    return "PLAYBOOK:\n" + "\n".join(lines) + "\n\n" + who


# ---------------------------------------------------------------------------
# Text extraction
# ---------------------------------------------------------------------------
def docx_to_text(raw):
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        xml = z.read("word/document.xml").decode("utf-8", "ignore")
    xml = re.sub(r"<w:tab[^>]*/>", "\t", xml)
    xml = re.sub(r"<w:br[^>]*/>", "\n", xml)
    paras = re.split(r"</w:p>", xml)
    out = []
    for p in paras:
        t = re.sub(r"<[^>]+>", "", p)
        t = html.unescape(t).strip()
        if t:
            out.append(t)
    return "\n".join(out)


def build_content(payload):
    """Turn the upload into AI message content blocks."""
    name = (payload.get("filename") or "").lower()
    text = payload.get("text")
    data = payload.get("data")
    if text and text.strip():
        return [{"type": "text", "text": "CONTRACT:\n\n" + text.strip()}]
    if not data:
        raise ValueError("No contract received. Upload a file or paste the text.")
    raw = base64.b64decode(data)
    if len(raw) > MAX_UPLOAD:
        raise ValueError("File is larger than 15 MB.")
    if name.endswith(".pdf"):
        return [{"type": "document", "source": {"type": "base64", "media_type": "application/pdf", "data": data}}]
    if name.endswith(".docx"):
        t = docx_to_text(raw)
        if not t.strip():
            raise ValueError("This Word file has no readable text.")
        return [{"type": "text", "text": "CONTRACT:\n\n" + t}]
    if name.endswith((".txt", ".md")):
        return [{"type": "text", "text": "CONTRACT:\n\n" + raw.decode("utf-8", "ignore")}]
    raise ValueError("Unsupported file type. Use PDF, Word (.docx) or .txt. Old .doc files must be saved as .docx first.")


# ---------------------------------------------------------------------------
# AI API call
# ---------------------------------------------------------------------------
def call_ai(content, side):
    key = os.environ.get("AI_API_KEY", "").strip()
    if not key:
        raise PermissionError("No API key set. Add AI_API_KEY to the .env file in the clausekit folder, then restart the server.")
    if not MODEL:
        raise PermissionError("No model set. Add AI_MODEL to the .env file in the clausekit folder, then restart the server.")
    body = {
        "model": MODEL,
        "max_tokens": 6000,
        "system": SYSTEM_PROMPT,
        "messages": [{
            "role": "user",
            "content": [{"type": "text", "text": playbook_text(side)}] + content +
                       [{"type": "text", "text": "Review this contract now. Reply with the JSON object only."}],
        }],
    }
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=json.dumps(body).encode(),
        headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=180, context=ssl.create_default_context()) as r:
            resp = json.loads(r.read())
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "ignore")
        try:
            detail = json.loads(detail)["error"]["message"]
        except Exception:
            pass
        raise RuntimeError(f"The AI service returned an error ({e.code}): {detail}")
    except urllib.error.URLError as e:
        raise RuntimeError(f"Could not reach the AI service: {e.reason}. Check your internet connection.")

    text = "".join(b.get("text", "") for b in resp.get("content", []) if b.get("type") == "text")
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        raise RuntimeError("The AI reply could not be read. Try again.")
    result = json.loads(m.group(0))
    usage = resp.get("usage", {})
    result["tokens"] = usage.get("input_tokens", 0) + usage.get("output_tokens", 0)
    return result


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------
class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=HERE, **kw)

    def send_json(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/api/health":
            return self.send_json(200, {
                "ai_ready": bool(os.environ.get("AI_API_KEY", "").strip()) and bool(MODEL),
                "model": MODEL,
                "playbook": [{"id": p, "title": t, "rule": r} for p, t, r in PLAYBOOK],
            })
        # never serve hidden files like .env
        if "/." in self.path:
            return self.send_error(404)
        return super().do_GET()

    def do_POST(self):
        if self.path != "/api/review":
            return self.send_error(404)
        length = int(self.headers.get("Content-Length") or 0)
        if length > MAX_UPLOAD * 1.4:
            return self.send_json(413, {"error": "File is larger than 15 MB."})
        try:
            payload = json.loads(self.rfile.read(length) or b"{}")
            content = build_content(payload)
            result = call_ai(content, payload.get("side", ""))
            self.send_json(200, result)
        except PermissionError as e:
            self.send_json(503, {"error": str(e), "setup": True})
        except (ValueError, zipfile.BadZipFile, KeyError) as e:
            self.send_json(400, {"error": str(e) if str(e) else "Could not read this file."})
        except Exception as e:
            self.send_json(502, {"error": str(e)})

    def log_message(self, fmt, *args):
        sys.stderr.write("%s %s\n" % (self.command if hasattr(self, "command") else "", fmt % args))


if __name__ == "__main__":
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    print(f"ClauseKit running at http://localhost:{PORT}  (AI key {'found' if os.environ.get('AI_API_KEY') else 'NOT set'}, model {MODEL or 'NOT set'})")
    srv.serve_forever()

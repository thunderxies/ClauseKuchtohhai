# ClauseKit

AI-assisted contract drafting and review for Indian law. Prototype.

## What's inside

| File | What it does |
|---|---|
| `index.html` | **Drafter.** Form that builds a Mutual NDA or Service Agreement from a clause library, with rule-based checks. Works offline. |
| `review.html` | **Review.** Upload a PDF, Word (.docx) or text contract; the AI flags risky clauses against the playbook and suggests replacement wording. |
| `server.py` | Local server. Serves both pages and the `/api/review` endpoint that calls the AI API. Python standard library only, no installs. |
| `.env.example` | Template for your API key. |

## Run it

```bash
cp .env.example .env        # then fill in AI_API_KEY and AI_MODEL
python3 server.py
```

Open http://localhost:8765 (Drafter) or http://localhost:8765/review.html (Review).

Never commit `.env` to git.

## Where the legal knowledge lives

- **Drafting clauses:** the `CLAUSES` array in `index.html`. Each clause has an id, the contract types it applies to, a condition, and its text.
- **Review playbook:** the `PLAYBOOK` list at the top of `server.py`. Each entry is the firm's standard position on one topic. The AI cites these ids in its findings.

The lawyer partner should rewrite both. That is the product's real value.

## API

- `GET /api/health` → `{ ai_ready, model, playbook }`
- `POST /api/review` with JSON `{ side: "client"|"provider"|"", filename, data (base64) }` or `{ side, text }`
  → `{ contract_type, parties, summary, overall_risk, issues[], missing[] }`

Settings in `.env`: `AI_API_KEY` (required), `AI_MODEL` (required), `PORT` (default 8765).

## Not built yet

- Logins, saved drafts, database
- Word/PDF download of drafts
- More contract types
- Data privacy compliance system (idea #2)

AI output is a first pass for a lawyer to check, not legal advice.
